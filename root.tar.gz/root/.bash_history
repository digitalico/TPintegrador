history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostname
dpkg-reconfigure keyboard-configuration
dpkg-reconfigure keyboard-configuration
dpkg-reconfigure keyboard-configuration
clear
hostname tpserver
hostname
vim /etc/hostname
cat /etc/hostname
hostname
pwd
ls
ls -la
cd /
ls -la
pwd
ls -la
ls /dev
ping -c 4 google.com
apt update
apt full-upgrade -y
reboot
apt full-upgrade -y
cat /etc/apt/source.list
cat /etc/apt/sources.list
sed -i s/bullseye/bookworm/g' /etc/apt/sources.list
apt update
sed -i 's/bullseye/bookworm/g' /etc/apt/sources.list
apt update 
apt full-upgrade -y
cat /etc/apt/sources.list
apt update
vim /etc/apt/sources.list
apt update
vim /etc/apt/sources.list
apt update
apt full-upgrade -y
cat /etc/os-release
reboot
shutdown
poweroff
lsblk
df -h
pwd
mkdir /www_dir
mkdir /backup_dir
ls
cd
ls
cd /
pwd
cd /
pwd
ls
clear
systemctl status ssh
apt install openssh-server -y
openssh
openssh-server
systemctl status ssh
clear
ls -la /root/.ssh
ssh-keygen
cat /root/.ssh/id_rsa.pub >> /root/.ssh/authorized_keys
cat /root/.ssh/authorized_keys
grep -E 'PermitRootLogin|PubkeyAuthentication' /etc/ssh/sshd_config
vim /etc/ssh/sshd_config
systmctl restart ssh
systemctl restart ssh
systemctl status ssh 
clear
apt install apache2 php -y
systemctl status apache2
ip a
clear
ls /root
tar -xzf /root/Material_Adicional_TPVMCA.tar.gz -C /root
ls /root
ls -la /root
tar -xf /root/Material_Adicional_TPVMCA
ls /Material_Adicional_TPVMCA
ls
ls /root
vim /ROOT/Material_Adicional_TPVMCA
clear
cd /root/Material_adicional_TPVMCA
cd root
ls
cd Material_Adicional_TPVMCA
LS
ls
cp index.php /var/www/html/
at index.php
cat index.php
vim index.php
clear
apt install php-mysql -y 
systemctl restart apache2
install mariadb-server -y
apt install mariadb-server -y
clear
systemctl status mariadb
head db.sql
mysql < dbsql
mysql < db.sql
mysql
cp logo.png /var/www/html/
ip route
cat /etc/network/interfaces
vim /etc/network/interfaces
reboot
ip a
poweroff
lslbk
lsblk
fdisk /dev/sdc
lsblk
poweroff
fdisk -l
lslblk
lsblk
mkfs -t ext4 /dev/sdc1
mkfs -t ext4 /dev/sdc2
fstab
/etc/fstab
poweroff
lsblk
fdisk -l /dev/sdc
cat /etc/fstab
clear
cat /etc/fstab
lsblk
mkfs.ext4 /dev/sdc1
mksf.ext4 /dev/sdc2
mkfs.ext4 /dev/sdc2
ls /dev/sdc1
cd /dev/sdc1
blkid
clear
blkid
mkdir /www_dir
ls /
ls /aux
cd /aux
ls
cd
lbbkl
lsblk
ls /www_dir
mount /dev/sdc1 /www_dir
df -h
mount /dev/sdc2 /backup_dir
df -h
clear
cp /etc/fstab /etc/fstab.bak
vim /etc/fstab
clear
fstab
mount -a
ls /root
ls root/
ls /root/
ls Material_Adicional_TPVMCA
find / -type d -name "Materia_Adicional_TPVMCA" 2>/dev/null
cp /root/Material_Adicional_TPVMCA/index.php /www_dir/
cp /root/Material_Adicional_TPVMCA/logo.png /www_dir/
ls /www_dir
cat /etc/apache2/sites-avaible/000-default.conf
cat /etc/apache2/sites-available/000-default.conf
cp /etc/apache2/site_available/000-default.conf /etc/apache2/sites-available/000-default.conf.bak
cp /etc/apache2/sites-available/000-default.conf /etc/apache2/sites-available/000-default.conf.bak
ls /etc/apache2/sites-available/
cp /etc/apache2/apache2.conf /etc/apache2/apache2.conf.bak
ls /etc/apache2/
clear
vim /etc/apache2/sites-available/000-default.conf
vim /etc/apache2/apache2.conf
clear
apache2ctl configtest
vim /etc/apache2/sites-available/000-default.conf
apache2ctl configtest
clear
systemctl reload apache2
cat /proc7partitions
cat /proc/partitions
cat /proc/partitions > /opt/particion
cat /opt/particion
poweroff
