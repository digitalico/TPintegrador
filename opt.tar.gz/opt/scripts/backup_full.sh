#!/bin/bash

# backup_full.sh
# Hace un backup comprimido (.tar.gz) de un directorio origen hacia un destino
# Uso: ./backup_full.sh <origen> <destino>

# === Ayuda ===
if [ "$1" = "-help" ]; then
    echo " backup_full.sh - Script de backup comprimido "
    echo ""
    echo " Uso: "
    echo "  ./backup_full.sh <origen> <destino> "
    echo ""
    echo " Argumentos: "
    echo " origen   Directorio a backupear (debe existir) "
    echo " destino  Directorio donde guardar el backup (debe existir) "
    echo ""
    echo " Ejemplos: "
    echo "  ./backup_full.sh /var/log /backup_dir "
    echo "  ./backup_full.sh /www_dir /backup_dir "
    echo ""
    echo " Notas: "
    echo " - El archivo generado tiene el formato: <nombre>_bkp_YYYYMMDD.tar.gz "
    echo " - Si origen o destino no existen, el script termina con error. "
    exit 0
fi

ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)

# ============ NUEVO: validaciones ==========
if [ ! -d "$ORIGEN" ]; then
   echo "Error: el directorio origen '$ORIGEN' no existe."
   exit 1

fi

if [ ! -d "$DESTINO" ]; then
   echo "Error: el directorio destino '$DESTINO' no existe."
   exit 1

fi
# ============ FIN de bloque nuevo ========

NOMBRE=$(basename $ORIGEN)
ARCHIVO="${DESTINO}/${NOMBRE}_bkp_${FECHA}.tar.gz"

tar czvf $ARCHIVO $ORIGEN

echo "Backup creado: $ARCHIVO"
